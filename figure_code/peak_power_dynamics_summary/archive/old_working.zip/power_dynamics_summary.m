function power_dynamics_summary(data, stages, stage_props, Fs, freq_range, SOpow, SOpow_times, SOpow_hist, SOpow_bins, SOpow_freqs, peak_freqs, peak_times, peak_proms, time_window, fwindow_size)

%Compute the full-night spectrogram
[spect,stimes,sfreqs]=multitaper_spectrogram_mex(data,Fs,freq_range,[15 29],[30 15],[],'linear',[],false,true,true);

%Compute the rate reconstruction
[rate_true, rate_recon, rate_times] = SOpow_hist_rate_recon(SOpow, SOpow_times, SOpow_hist, SOpow_bins, SOpow_freqs,...
    peak_freqs, peak_times, time_window, fwindow_size, false);

lightsout = stages.time(find(stages.stage ~= 5,1,'first'))-5*60;
lightson = 33353 + 2.5*60; % BAD ENDING DATA stages.time(find(stages.stage ~= 5,1,'last'))+5*60;

%% CREATE FIGURE

%% Generate axes
figure
ax = figdesign(7,2,'type','usletter','orient','portrait','merge',{1:2, 3:4, [5 7 9 ],[6 8 10], 11:12, 13:14},'margins', [.01 .05 .05 .05 .08 .04]);
set(gcf,'units','normalized');

spect_axes = split_axis(ax(1),[.7 .3],1);
peak_axes = split_axis(ax(2),[.3 .7],1);
SOPH_axes = [split_axis(ax(3),[.2 .8],1) split_axis(ax(4),[.2 .8],1)];
recon_axes = ax(end-1:end)';

linkaxes([spect_axes peak_axes recon_axes],'x');

%% Hypnogram/Spectrogram

%Hypnogram
axes(spect_axes(2))
hypnoplot(stages);
set(gca,'xtick',[]);

%Spectrogram
axes(spect_axes(1))
imagesc(stimes,sfreqs,pow2db(spect'));
axis xy;
climscale;
colormap(spect_axes(1),jet);
scaleline(spect_axes(1), 3600,'1 Hour' );

ylabel('Freq. (Hz)')

%% Peak Scatter Plot

%Peak scatter plot
axes(peak_axes(2))
good_inds=peak_proms>0;

psize=(peak_proms(good_inds));
psize(isinf(psize))=1e-100;
psize(psize<=0)=1e-100;

scatter(peak_times, peak_freqs, (psize)/400, 'k')
ylim(freq_range);
ylabel('Freq. (Hz)');
set(gca,'xtick',[]);

%SO power trace
axes(peak_axes(1))
plot(SOpow_times,SOpow*100);
ylim([0 100])

scaleline(peak_axes(1), 3600,'1 Hour' );

%% SO-power Histogram

%Plot the histogram
axes(SOPH_axes(2))
imagesc(SOpow_bins*100, SOpow_freqs, SOpow_hist);
axis xy;
climscale(SOPH_axes(2),[2.5 97.5],false)
cx=caxis;

colormap(SOPH_axes(1),"parula");
set(gca,'xtick',[]);
ylabel('Frequency (Hz)')
title('SO-power Histogram')
cbar = colorbar_noresize;
cbar.Position(3:4) = cbar.Position(3:4)*.5;
cbar.Position(2) = SOPH_axes(2).Position(2) + (SOPH_axes(2).Position(4) - cbar.Position(4));
cbar.Label.String = {'Density (peaks/min in bin)'};

%Plot the time in bin
axes(SOPH_axes(1))
plot(SOpow_bins*100,stage_props'*100,'linewidth',2)
xlabel('% Slow Oscillation (db) Power')
ylabel('% Time')

%Integrated frequency
fastslow_ranges = [12.5 15; 10 12.5];
pows = 20:20:100;

axes(SOPH_axes(4))
hold on;
ylim(freq_range);

%Plot shaded regions
fill([0 100 100 0],[fastslow_ranges(1,1) fastslow_ranges(1,1) fastslow_ranges(1,2) fastslow_ranges(1,2)],[.8 .8 1],'EdgeColor','none')
fill([0 100 100 0],[fastslow_ranges(2,1) fastslow_ranges(2,1) fastslow_ranges(2,2) fastslow_ranges(2,2)],[1 .8 .8],'EdgeColor','none')

%Plot cross sections
[~, inds] = findclosest(SOpow_bins*100, pows);
hold on
for ii =1:length(pows)
    hist = (SOpow_hist(:,inds(ii)))*1.8;
    hist=hist-min(hist);
    plot(hist+pows(ii),SOpow_freqs,'linewidth',2);
end

ylim(freq_range)
xlim([0,100])
set(gca,'xtick',[]);
SOPH_axes(4).YAxisLocation = "right";
yl=ylabel('Frequency (Hz)');
yl.Rotation = -90;
yl.VerticalAlignment = "bottom";

%Plot integrated rate
axes(SOPH_axes(3))
 df = 1;
fast_rate = mean(SOpow_hist(SOpow_freqs>fastslow_ranges(1,1) & SOpow_freqs<fastslow_ranges(1,2),:))*df;
slow_rate = mean(SOpow_hist(SOpow_freqs>fastslow_ranges(2,1) & SOpow_freqs<fastslow_ranges(2,2),:))*df;

hold all
plot(SOpow_bins*100,fast_rate,'b','linewidth',2)
plot(SOpow_bins*100,slow_rate,'r','linewidth',2)
legend(sprintf('%2.1f - %2.1f Hz',fastslow_ranges(1,:)),sprintf('%2.1f - %2.1f Hz',fastslow_ranges(2,:)),'location','northwest')
SOPH_axes(3).YAxisLocation = "right";

yl = ylabel('Density');
yl.Rotation = -90;
yl.VerticalAlignment = "bottom";

%% RECONSTRUCTIONS

axes(recon_axes(1))
imagesc(rate_times,SOpow_freqs,rate_true);
axis xy;
title('Observed TF-peak Rate')
caxis(cx);
scaleline(recon_axes(1), 3600,'1 Hour' );
ylabel('Frequency (Hz)')

axes(recon_axes(2))
imagesc(rate_times,SOpow_freqs,rate_recon);
axis xy;
title('Reconstructed TF-peak Rate from SO-power Histogram and SO-power')
caxis(cx);
scaleline(recon_axes(2), 3600,'1 Hour' );
ylabel('Frequency (Hz)')


xlim([lightsout lightson]);%[3108 33435]);


% print -f1 -dpng -r300 power_dynamics_summary.png
